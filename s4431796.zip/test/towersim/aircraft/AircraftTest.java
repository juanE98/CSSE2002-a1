package towersim.aircraft;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class AircraftTest {

    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void getFuelAmount() {
    }

    @Test
    public void getFuelPercentRemaining() {
    }

    @Test
    public void getTotalWeight() {
    }

    @Test
    public void getTaskList() {
    }

    @Test
    public void getLoadingTime() {
    }

    @Test
    public void tick() {
    }

    @Test
    public void testToString() {
    }
}