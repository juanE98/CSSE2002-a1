package towersim.aircraft;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class FreightAircraftTest {

    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void getTotalWeight() {
    }

    @Test
    public void getLoadingTime() {
    }

    @Test
    public void calculateOccupancyLevel() {
    }

    @Test
    public void tick() {
    }
}