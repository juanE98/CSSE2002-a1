package towersim.aircraft;

import org.junit.Before;
import org.junit.Test;

public class PassengerAircraftTest {

    //Field Variables


    @Before
    public void setup() {

    }

    @Test
    public void getTotalWeightTest() {

    }

    @Test
    public void getTotalWeight() {
    }

    @Test
    public void getLoadingTime() {
    }

    @Test
    public void calculateOccupancyLevel() {
    }

    @Test
    public void tick() {
    }
}
