package towersim.control;

import org.junit.Test;

import static org.junit.Assert.*;

public class ControlTowerTest {

    @Test
    public void getAircraft() {
    }

    @Test
    public void findUnoccupiedGate​() {
    }

    @Test
    public void findGateOfAircraft​() {
    }

    @Test
    public void tick() {
    }
}